from django.shortcuts import render, redirect, reverse
from django.contrib import messages
from django.db.models import Q

from shop.models import Product


def search(request):
    q=request.GET.get('q')
    if q :
        queries = Q(name__icontains=q) | Q(description__icontains=q)
        products = Product.objects.filter(queries)
        return render(request, 'search.html', {'products': products, 'query': q})


